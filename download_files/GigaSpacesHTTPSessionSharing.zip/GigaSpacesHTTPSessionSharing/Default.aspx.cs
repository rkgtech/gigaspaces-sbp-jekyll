﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using GigaSpaces.Core;
using GigaSpaces.Core.Exceptions;
using GigaSpaces.Practices.HttpSessionProvider;
using System.Web.SessionState;
using System.Configuration;

public partial class index : System.Web.UI.Page
{
    Boolean isSessionFromUrl = false;
    String isWan = ConfigurationManager.AppSettings.Get("wan").ToString();
    
    String spaceUrl = ((ConnectionStringsSection)ConfigurationManager.GetSection("connectionStrings")).ConnectionStrings["SpaceSessionProviderURL"].ConnectionString;
    String url2 = ((ConnectionStringsSection)ConfigurationManager.GetSection("connectionStrings")).ConnectionStrings["SpaceSessionProviderURL-2"].ConnectionString;
    String url3 = ((ConnectionStringsSection)ConfigurationManager.GetSection("connectionStrings")).ConnectionStrings["SpaceSessionProviderURL-3"].ConnectionString;
    SessionDataEntry sde = null;        
    
    protected void Page_Load(object sender, EventArgs e)
    {

        lblSessionID.Text = Convert.ToString(Session.SessionID);
        lblSessionCreateTime.Text = Convert.ToString(Session["createTime"]);

        if (null != Request.QueryString["sessionId"] && isWan.Equals("true"))
        {
            isSessionFromUrl = true;
            lblSessionValue.Text += "<b>Using WAN Deployment</b></br>";
            if (null != spaceUrl) DisplaySessionValuesFromWAN(spaceUrl);
            if (null != url2) DisplaySessionValuesFromWAN(url2);
            if (null != url3) DisplaySessionValuesFromWAN(url3);

        }
        else if (null != Request.QueryString["sessionId"] && isWan.Equals("false"))
        {
            isSessionFromUrl = true;
            lblSessionValue.Text += "<b>Not Using WAN Deployment</b></br>";
            DisplaySessionValues();            
        }
        else
        {
            DisplaySessionValues();
        }
    }

    protected void btnCreateSession_Click(object sender, EventArgs e)
    {
        if (!isSessionFromUrl)
        {
            Session.Add(txtSessionAttributeName.Text.Trim(), txtSessionAttributeValue.Text.Trim());
            DisplaySessionValues();
        }
    }
    /**
    protected void btnRetrieveSession_Click(object sender, EventArgs e)
    {
        DisplaySessionValues();
    }
    **/
    protected void btnRemoveSession_Click(object sender, EventArgs e)
    {
        Session.Remove(txtSessionAttributeName.Text.Trim());

        DisplaySessionValues();
    }
    protected SessionDataEntry getSDE(String spaceUrl)
    {
        // Connect to space:
        sde = null;
        try
        {
            ISpaceProxy proxy = GigaSpacesFactory.FindSpace(spaceUrl);
            //lblSessionValue.Text += "WAN Deployment = <b>" + isWan + "</b>. Connecting to spaces....<br />";
            //lblSessionValue.Text += "Fetching data using " + proxy.FinderUrl.ToString().Substring(0, proxy.FinderUrl.ToString().IndexOf("?")) + "<br />";
            SqlQuery<SessionDataEntry> query = new SqlQuery<SessionDataEntry>("SessionId like '" + Request.QueryString["sessionId"] + "%'");
            //query.Routing = 1;
            sde = proxy.Read<SessionDataEntry>(query);
            
        }
        catch (Exception ex)
        {
            lblSessionValue.Text += "Could not connect to " + spaceUrl + ". Please check your settings. </br>";
        }
        return sde;
                    
    }
    
    private void DisplaySessionValues()
    {
        lblSessionValue.Text = "";

        if (isSessionFromUrl)
        {
            if (null != Request.QueryString["sessionId"])
            {
                if (null != getSDE(spaceUrl))
                {
                    SessionStateItemCollection sessionStuff = (SessionStateItemCollection)sde.GetSessionStateStoreData().Items;
                    // Creates a Session Data Entry template for this application
                    lblSessionValue.Text += "Data In Session Id from URL (<b>" + Request.QueryString["sessionId"] + "</b>)<br />";
                    
                    int i = 0;
                    for (i = 0; i < sessionStuff.Count; i++)
                    {
                        if (sessionStuff != null)
                        {
                            
                            //if (sessionStuff.Keys[i] != "createTime")
                            //{
                                //lblSessionValue.Text += sessionStuff.Keys[i] + " = " + sessionStuff[i].ToString() + "<br />"
                                //    + "<a href=\"javascript:edit('" + sessionStuff.Keys[i] + "','" + sessionStuff[i].ToString() + "');\">Edit</a>&nbsp;|&nbsp;<a href=\"javascript:remove('" + i + "')\">Delete</a><br />";
                                lblSessionValue.Text += sessionStuff.Keys[i] + " = " + sessionStuff[i].ToString() + "<br />";
                            //}
                        }
                    }
                }
                else
                {
                    lblSessionValue.Text += "No session data available for SessionID <b>" + Request.QueryString["sessionId"] + "</b> <br />";
                }


            }
        }
        else
        {

            foreach (string i in Session.Contents)
            {
                if (Session[i] != null)
                {
                    if (i != "createTime")
                    {
                        lblSessionValue.Text += i + " = " + Session[i].ToString() + "<br />"
                            + "<a href=\"javascript:edit('" + i + "','" + Session[i].ToString() + "');\">Edit</a>&nbsp;|&nbsp;<a href=\"javascript:remove('" + i + "')\">Delete</a><br />";
                    }
                    else
                    {
                        lblSessionValue.Text += i + " = " + Session[i].ToString() + "<br />";
                    }
                }
            }
        }
        
        
    }

    private void DisplaySessionValuesFromWAN(String url)
    {
        //lblSessionValue.Text = "";

        if (isSessionFromUrl)
        {
            if (null != Request.QueryString["sessionId"])
            {
                if (null != getSDE(url))
                {
                    SessionStateItemCollection sessionStuff = (SessionStateItemCollection)sde.GetSessionStateStoreData().Items;
                    // Creates a Session Data Entry template for this application
                    lblSessionValue.Text += "Data In Session Id from URL (<b>" + Request.QueryString["sessionId"] + "</b>) for space " + url + "<br />";

                    int i = 0;
                    for (i = 0; i < sessionStuff.Count; i++)
                    {
                        if (sessionStuff != null)
                        {

                            //if (sessionStuff.Keys[i] != "createTime")
                            //{
                                //lblSessionValue.Text += sessionStuff.Keys[i] + " = " + sessionStuff[i].ToString() + "<br />"
                                //    + "<a href=\"javascript:edit('" + sessionStuff.Keys[i] + "','" + sessionStuff[i].ToString() + "');\">Edit</a>&nbsp;|&nbsp;<a href=\"javascript:remove('" + i + "')\">Delete</a><br />";
                                lblSessionValue.Text += sessionStuff.Keys[i] + " = " + sessionStuff[i].ToString() + "<br />";
                                
                            //}
                        }
                    }
                    lblSessionValue.Text += "---------------------------------------- <br />";
                }
                else
                {
                    lblSessionValue.Text += "No session data available for SessionID <b>" + Request.QueryString["sessionId"] + "</b> in space " + url + " <br />";
                    lblSessionValue.Text += "---------------------------------------- <br />";
                }


            }
        }

    }

}